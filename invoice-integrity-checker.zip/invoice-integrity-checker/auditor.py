"""Invoice Integrity Checker — offline CSV validation with Decimal arithmetic."""
from __future__ import annotations
import argparse
import csv
import html
import json
import re
from collections import Counter
from dataclasses import dataclass, asdict
from datetime import date
from decimal import Decimal, InvalidOperation
from pathlib import Path

FIELDS = ("invoice_no", "supplier", "invoice_date", "currency", "subtotal", "tax", "total")
CURRENCIES = {"USD", "LRD", "MYR", "EUR", "GBP"}


@dataclass
class AuditResult:
    row: int
    invoice_no: str
    supplier: str
    issues: list[str]
    status: str
    currency: str
    subtotal: str
    tax: str
    total: str


def money(raw: str) -> Decimal:
    text = str(raw).strip().replace(",", "")
    if not text:
        raise ValueError("missing amount")
    try:
        value = Decimal(text)
    except InvalidOperation as exc:
        raise ValueError("not a valid number") from exc
    if not value.is_finite() or value < 0:
        raise ValueError("must be finite and non-negative")
    if value.as_tuple().exponent < -2:
        raise ValueError("more than two decimal places")
    return value.quantize(Decimal("0.01"))


def audit_rows(rows: list[dict[str, str]]) -> list[AuditResult]:
    """Read-only validation; never alters invoice numbers or imported records."""
    seen = set()
    report = []
    for row_no, row in enumerate(rows, 2):
        clean = {key: str(row.get(key) or "").strip() for key in FIELDS}
        issues = []
        invoice = clean["invoice_no"]
        supplier = clean["supplier"]
        if not invoice:
            issues.append("Missing invoice number")
        if not supplier:
            issues.append("Missing supplier")
        if invoice and supplier:
            key = (supplier.casefold(), invoice.casefold())
            if key in seen:
                issues.append("Duplicate supplier + invoice number")
            seen.add(key)
        if not clean["invoice_date"]:
            issues.append("Missing invoice date")
        else:
            try:
                if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", clean["invoice_date"]):
                    raise ValueError("Date must use YYYY-MM-DD")
                date.fromisoformat(clean["invoice_date"])
            except ValueError:
                issues.append("Invalid invoice date (use YYYY-MM-DD)")
        if clean["currency"].upper() not in CURRENCIES:
            issues.append("Unsupported or missing currency")
        parsed = {}
        for field in ("subtotal", "tax", "total"):
            try:
                parsed[field] = money(clean[field])
            except ValueError as exc:
                issues.append(f"Invalid {field}: {exc}")
        if len(parsed) == 3 and parsed["subtotal"] + parsed["tax"] != parsed["total"]:
            issues.append("Math mismatch: subtotal + tax != total")
        report.append(AuditResult(
            row=row_no, invoice_no=invoice, supplier=supplier,
            issues=issues, status="PASS" if not issues else "REVIEW",
            currency=clean["currency"].upper(), subtotal=clean["subtotal"],
            tax=clean["tax"], total=clean["total"]
        ))
    return report


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames:
            raise ValueError("CSV is empty")
        missing = set(FIELDS) - {field.strip() for field in reader.fieldnames if field}
        if missing:
            raise ValueError("Missing required CSV columns: " + ", ".join(sorted(missing)))
        return list(reader)


def summary(results: list[AuditResult]) -> dict:
    counts = Counter(issue for record in results for issue in record.issues)
    return {
        "total": len(results),
        "passed": sum(item.status == "PASS" for item in results),
        "review": sum(item.status == "REVIEW" for item in results),
        "issue_counts": dict(sorted(counts.items())),
    }


def build_html(results: list[AuditResult], source_label: str = "invoices.csv") -> str:
    s = summary(results)
    trs = []
    for item in results:
        flag = "pass" if item.status == "PASS" else "review"
        issue_list = "<br>".join(html.escape(issue) for issue in item.issues) or "—"
        trs.append("<tr><td>{}</td><td>{}</td><td>{}</td><td><span class='{}'>{}</span></td><td>{}</td><td>{}</td><td>{}</td></tr>".format(
            item.row, html.escape(item.invoice_no or "—"), html.escape(item.supplier or "—"),
            flag, html.escape(item.status), html.escape(item.currency),
            html.escape(item.total), issue_list))
    return """<!doctype html><html lang='en'><head><meta charset='utf-8'>
<meta name='viewport' content='width=device-width,initial-scale=1'>
<title>Invoice Integrity Report</title>
<style>
:root{font-family:Inter,'Segoe UI',Arial,sans-serif;color:#142337;background:#f3f5f9}
*{box-sizing:border-box}body{margin:0}main{max-width:1200px;margin:0 auto;padding:40px 22px}
header{background:#13213a;color:white;padding:28px;border-radius:20px}header small{color:#9ec6ff;letter-spacing:.1em;font-weight:700}header h1{margin:8px 0 4px;font-size:clamp(24px,3vw,37px)}header p{color:#cbd7e5;margin:0}
.stats{display:flex;gap:15px;flex-wrap:wrap;margin:24px 0}.stat{flex:1;min-width:150px;background:white;border:1px solid #e1e6ee;border-radius:14px;padding:20px}.stat span{color:#56677f}.stat strong{display:block;font-size:33px;margin-top:7px}
.panel{overflow-x:auto;background:white;border:1px solid #e0e6ef;border-radius:15px}table{width:100%%;border-collapse:collapse;font-size:14px}th{text-align:left;background:#edf2f9;padding:14px}td{padding:14px;vertical-align:top;border-top:1px solid #edf0f4}.pass{color:#126d4c;font-weight:800}.review{color:#a5530c;font-weight:800}footer{font-size:12px;color:#66768b;margin-top:18px}
</style></head><body><main>
<header><small>QUALITY CONTROL / OFFLINE</small><h1>Invoice Integrity Report</h1><p>Source: %s · Validation only. Human review required before financial approval.</p></header>
<section class='stats'><div class='stat'><span>Invoices checked</span><strong>%d</strong></div><div class='stat'><span>Passed</span><strong>%d</strong></div><div class='stat'><span>Need review</span><strong>%d</strong></div></section>
<section class='panel'><table><thead><tr><th>CSV row</th><th>Invoice</th><th>Supplier</th><th>Result</th><th>Currency</th><th>Reported total</th><th>Issues</th></tr></thead><tbody>%s</tbody></table></section>
<footer>No invoices were edited, posted, issued or approved by this report.</footer>
</main></body></html>""" % (html.escape(source_label), s["total"], s["passed"], s["review"], "\n".join(trs))


def write_reports(results: list[AuditResult], output_dir: Path, source_label: str) -> tuple[Path, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    report_json = output_dir / "report.json"
    report_html = output_dir / "report.html"
    report_json.write_text(json.dumps({"summary": summary(results), "invoices": [asdict(x) for x in results]}, indent=2), encoding="utf-8")
    report_html.write_text(build_html(results, source_label), encoding="utf-8")
    return report_json, report_html


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Check invoice CSV data for duplicate numbers, incorrect totals and missing fields")
    parser.add_argument("--input", type=Path, required=True, help="Path to invoice CSV")
    parser.add_argument("--out", type=Path, default=Path("results"), help="Output report folder")
    args = parser.parse_args(argv)
    try:
        results = audit_rows(read_csv(args.input))
        json_file, html_file = write_reports(results, args.out, args.input.name)
    except (OSError, ValueError) as exc:
        parser.exit(2, f"Error: {exc}\n")
    overview = summary(results)
    print(f"Checked {overview['total']} invoices. PASS: {overview['passed']} | NEED REVIEW: {overview['review']}")
    print(f"JSON: {json_file}\nHTML: {html_file}")
    return 0 if overview["review"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
