@echo off
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (
  py -3 auditor.py --input samples\invoices.csv --out results
) else (
  python auditor.py --input samples\invoices.csv --out results
)
echo.
echo The sample intentionally includes issues, so a non-zero exit code is expected.
echo Open results\report.html in your browser.
pause
