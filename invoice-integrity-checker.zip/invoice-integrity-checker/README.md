# Invoice Integrity Checker 🧾

An offline Python utility for **auditing invoice CSV exports**. It flags duplicate references, invalid dates, missing fields and totals that don't add up, then generates a polished **HTML dashboard + JSON report**.

This is deliberately a *read-only review tool*, not an invoicing or approval system.

## Quick start

Requires Python 3.10+ and **no extra packages**.

```bash
python auditor.py --input samples/invoices.csv --out results
```

On Windows, simply double-click `RUN_DEMO_WINDOWS.bat` and open `results/report.html`. A pre-generated sample is also available at [`examples/report.html`](examples/report.html).

The sample intentionally includes problems, so the CLI returns exit code **1** when review is required; `0` means every record passed. Exit code `2` means bad input or a file error.

## CSV structure

| invoice_no | supplier | invoice_date | currency | subtotal | tax | total |
|---|---|---|---|---:|---:|---:|
| S-1001 | Sunrise Office Goods | 2026-11-02 | USD | 150.00 | 15.00 | 165.00 |

- `invoice_date` must be ISO `YYYY-MM-DD`.
- Supported currencies: USD, LRD, MYR, EUR and GBP; amounts stay in their source currency and are **never mixed together**.
- Duplicate identification uses `(supplier, invoice_no)` ignoring case. A repeated number from a *different supplier* is not automatically a duplicate.
- A mismatch is flagged if `subtotal + tax != total` using `Decimal` and two-decimal arithmetic.
- A human reviewer must check discounts, credit notes and unusual vendor formats separately.

## Automated tests

```bash
python -m unittest discover -s tests -v
```

## Portfolio description

> Created an offline invoice-auditing CLI that validates CSV exports using decimal-safe financial arithmetic, duplicate-reference detection and automated HTML/JSON reporting, with unit tests for validation and output escaping.

MIT licensed. The included invoices and vendors are fictitious.
