import csv
import json
import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from auditor import audit_rows, build_html, money, read_csv, summary, write_reports


def invoice(**overrides):
    d = {"invoice_no": "001", "supplier": "A", "invoice_date": "2026-11-24", "currency": "USD", "subtotal": "10.00", "tax": "1.00", "total": "11.00"}
    d.update(overrides)
    return d


class AuditTests(unittest.TestCase):
    def test_good_invoice_passes(self):
        self.assertEqual(audit_rows([invoice()])[0].status, "PASS")

    def test_duplicate_supplier_invoice_casefold(self):
        data = audit_rows([invoice(), invoice(supplier="a", invoice_no="001")])
        self.assertTrue(any("Duplicate" in x for x in data[1].issues))

    def test_same_invoice_different_supplier_allowed(self):
        data = audit_rows([invoice(), invoice(supplier="B")])
        self.assertTrue(all(x.status == "PASS" for x in data))

    def test_wrong_total(self):
        report = audit_rows([invoice(total="12.00")])[0]
        self.assertTrue(any("Math mismatch" in issue for issue in report.issues))

    def test_reject_invalid_money_and_date(self):
        report = audit_rows([invoice(subtotal="NaN", invoice_date="2026-02-30")])[0]
        self.assertGreaterEqual(len(report.issues), 2)
        with self.assertRaises(ValueError):
            money("1.234")

    def test_missing_currency_and_fields(self):
        report = audit_rows([invoice(currency="", invoice_no="", supplier="")])[0]
        self.assertEqual(report.status, "REVIEW")
        self.assertGreaterEqual(len(report.issues), 3)

    def test_html_escapes_invoices(self):
        html = build_html(audit_rows([invoice(supplier="<script>alert(1)</script>")]))
        self.assertIn("&lt;script&gt;", html)
        self.assertNotIn("<script>alert", html)

    def test_csv_and_reports(self):
        with tempfile.TemporaryDirectory() as tmp:
            src = Path(tmp) / "data.csv"
            with src.open("w", newline="", encoding="utf-8") as fh:
                writer = csv.DictWriter(fh, fieldnames=list(invoice()))
                writer.writeheader()
                writer.writerow(invoice())
            results = audit_rows(read_csv(src))
            self.assertEqual(summary(results)["passed"], 1)
            json_file, html_file = write_reports(results, Path(tmp) / "output", src.name)
            self.assertTrue(html_file.exists())
            self.assertEqual(json.loads(json_file.read_text())["summary"]["total"], 1)

    def test_missing_columns(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "bad.csv"
            path.write_text("invoice_no,supplier\n1,A\n", encoding="utf-8")
            with self.assertRaises(ValueError):
                read_csv(path)


if __name__ == "__main__":
    unittest.main()
